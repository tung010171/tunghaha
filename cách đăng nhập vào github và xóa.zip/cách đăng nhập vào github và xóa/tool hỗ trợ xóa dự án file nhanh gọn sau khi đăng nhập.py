import os
import subprocess
import sys

def clear_screen():
    os.system('clear')

def run_cmd(cmd_list, cwd=None):
    """Chạy lệnh shell và trả về (output, error, return_code)"""
    try:
        result = subprocess.run(cmd_list, cwd=cwd, capture_output=True, text=True)
        return result.stdout.strip(), result.stderr.strip(), result.returncode
    except Exception as e:
        return "", str(e), 1

def is_git_repo(path):
    """Kiểm tra xem thư mục có phải là Git repo không"""
    return os.path.isdir(os.path.join(path, '.git'))

def setup_git():
    print("\n--- CẤU HÌNH GIT & GITHUB ---")
    out, _, _ = run_cmd(["git", "config", "--global", "user.name"])
    if not out:
        name = input("Nhập tên Git (user.name): ").strip()
        if name: run_cmd(["git", "config", "--global", "user.name", name])
    
    out, _, _ = run_cmd(["git", "config", "--global", "user.email"])
    if not out:
        email = input("Nhập email Git (user.email): ").strip()
        if email: run_cmd(["git", "config", "--global", "user.email", email])
    
    print("\nKiểm tra đăng nhập GitHub CLI...")
    _, err, code = run_cmd(["gh", "auth", "status"])
    if code != 0:
        print("[!] Bạn chưa đăng nhập GitHub CLI. Bắt đầu đăng nhập...")
        os.system("gh auth login")
    else:
        print("[✓] Đã đăng nhập GitHub CLI.")

def scan_files(folder):
    """Quét toàn bộ file bằng os.walk"""
    file_list = []
    for root, dirs, files in os.walk(folder):
        # Bỏ qua thư mục .git
        if '.git' in dirs:
            dirs.remove('.git')
        for file in files:
            full_path = os.path.join(root, file)
            # Lấy đường dẫn tương đối để hiển thị cho gọn
            rel_path = os.path.relpath(full_path, folder)
            file_list.append((rel_path, full_path))
    return file_list

def main():
    clear_screen()
    print("=====================================")
    print("   TOOL QUẢN LÝ & XÓA FILE GITHUB")
    print("=====================================")
    
    # 1. Nhập thư mục
    folder = input("Nhập đường dẫn thư mục cần quét (Enter để dùng thư mục hiện tại): ").strip()
    if not folder:
        folder = os.getcwd()
    
    folder = os.path.abspath(os.path.expanduser(folder))
    if not os.path.isdir(folder):
        print(f"[!] Lỗi: Thư mục '{folder}' không tồn tại.")
        return

    if is_git_repo(folder):
        print(f"[✓] Đã phát hiện Git repository tại: {folder}")
        setup_git()
    else:
        print(f"[!] Cảnh báo: '{folder}' không phải là Git repository. Sẽ chỉ xóa file cục bộ.")

    # 2. Quét file
    files = scan_files(folder)
    if not files:
        print("[!] Không tìm thấy file nào trong thư mục này.")
        return

    print("\n===== DANH SÁCH FILE =====")
    for idx, (rel_path, _) in enumerate(files, 1):
        print(f"{idx}. {rel_path}")
    print("==========================")

    # 3. Chọn file để xóa
    while True:
        user_input = input("\nNhập số file muốn xóa (cách nhau bởi dấu phẩy, vd: 1,3): ").strip()
        if not user_input:
            continue
        
        try:
            indices = [int(x.strip()) for x in user_input.split(',')]
            if any(i < 1 or i > len(files) for i in indices):
                print("[!] Lỗi: Số thứ tự không hợp lệ. Vui lòng nhập lại.")
                continue
            break
        except ValueError:
            print("[!] Lỗi: Vui lòng chỉ nhập số.")

    # 4. Xác nhận
    print("\nBạn chọn xóa các file sau:")
    for i in indices:
        print(f" - {files[i-1][0]}")
    
    confirm = input("Xác nhận xóa? (y/n): ").strip().lower()
    if confirm != 'y':
        print("[!] Đã hủy bỏ xóa file.")
        return

    # 5. Tiến hành xóa
    deleted_files = []
    for i in indices:
        rel_path, full_path = files[i-1]
        try:
            os.remove(full_path)
            print(f"[✓] Đã xóa: {rel_path}")
            deleted_files.append(rel_path)
        except Exception as e:
            print(f"[!] Lỗi khi xóa {rel_path}: {e}")

    if not deleted_files:
        return

    # 6. Cập nhật lên GitHub (nếu là Git repo)
    if is_git_repo(folder):
        print("\n--- CẬP NHẬT LÊN GITHUB ---")
        out, _, _ = run_cmd(["git", "status", "--porcelain"], cwd=folder)
        print(f"Trạng thái Git:\n{out if out else 'Không có thay đổi'}")
        
        do_commit = input("\nBạn có muốn commit và push các thay đổi này lên GitHub? (y/n): ").strip().lower()
        if do_commit == 'y':
            print("\nĐang thêm file...")
            run_cmd(["git", "add", "-A"], cwd=folder)
            
            commit_msg = input("Nhập nội dung commit (Enter để dùng mặc định): ").strip()
            if not commit_msg:
                commit_msg = "Delete selected files"
                
            print("Đang commit...")
            out, err, code = run_cmd(["git", "commit", "-m", commit_msg], cwd=folder)
            if code != 0 and "nothing to commit" not in out and "nothing to commit" not in err:
                print(f"[!] Lỗi commit:\n{err}")
                return
            else:
                print("[✓] Commit thành công.")

            print("Đang push lên GitHub...")
            out, err, code = run_cmd(["git", "push", "origin", "main"], cwd=folder)
            if code == 0:
                print("[✓] Push thành công lên GitHub!")
            else:
                # Thử push nhánh master nếu nhánh main không tồn tại
                print("[!] Push nhánh main thất bại, đang thử nhánh master...")
                out, err, code = run_cmd(["git", "push", "origin", "master"], cwd=folder)
                if code == 0:
                    print("[✓] Push thành công lên GitHub (nhánh master)!")
                else:
                    print(f"[!] Push thất bại. Chi tiết lỗi:\n{err}")
                    print("Vui lòng kiểm tra kết nối mạng hoặc đăng nhập lại bằng 'gh auth login'.")
        else:
            print("[!] Đã hủy push lên GitHub.")
    else:
        print("\n[!] Thư mục này không phải Git repo, không thể push lên GitHub.")

if __name__ == "__main__":
    main()